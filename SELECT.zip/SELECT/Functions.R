# Name: Module des fonctions auxiliaires. 
# Author: Louis-Marc Mercier
# Date: July 6th 2016

# L'idee de ce script est de mettre en place des fonctions auxiliaires qui faciliteront
# la séparation de données et la sélection de variables selon SELECT() et ses variantes.

#############################################
############ Load librairies ################
#############################################

# Librairies
library(install.load)
install_load(c("devtools","arm","Boruta","elasticnet","h2o","plyr","e1071","AUC","caret","dplyr","kernlab","pROC","varhandle"))
# install_github('ramhiser/datamicroarray')
library(datamicroarray)

# Action: Importe les fichiers csv a partir d'un dossier choisit towards the global environnement. 
#         The function returns the names of all the imported files.
# import_path: A character vector of full path names.
# ext: Type of file. 
Import = function(import_path,ext){
  my_files_names = list.files(path=import_path,pattern=ext)
  for (i in 1:length(my_files_names)) assign(my_files_names[i],read.csv(paste(import_path,"/",my_files_names[i],sep="")),inherits = T)
  return(my_files_names)
}

# Action: Exporte un tableau vers un dossier choisi.
# name: Nom du fichier.
# dataframe: Tableau a exporter.
# i: Nombre associe a l'experience.
Export = function(export_path,name,dataframe,i){
  new_name = paste("/","exp",i,"/",name,i,".csv",sep="")
  write.csv(dataframe,file=paste(basic_path,new_name,sep=""),row.names = F)
}

# Action: Determine le seuil neccesaire a une matrice pour avoir un certain 
#         niveau de sparsity.
# mat: Matrice pour laquelle il faut analyser la sparsity
# nb_pts: Nombre de points total ou l'on evalue la sparsity.
# prop_sparse: Proportion de zeros voulu.
u_sparse = function(mat,nb_pts,prop_sparse){
  le_max=max(abs(mat))
  palette=seq(from = 0, to = le_max, by = le_max/(nb_pts-1))
  sparse_resultats=vector()
  for(i in 1:length(palette)){
    ind_mat=1*(abs(mat)>palette[i])
    sparse_resultats[i]=sum(ind_mat==0)/(nrow(ind_mat)*ncol(ind_mat))
  }
  distance_l1=abs(prop_sparse-sparse_resultats)
  pos=which.min(distance_l1)
  return(palette[pos])
}

# Action: Fonction qui trouve les rangees avec le plus de de poids non-nuls.
# V: Matrice de rotation des genes.
# u: Seuil de troncage des elements de la matrice de rotation.
# prop_genes: Pourcentage de genes a conserver.
trouve_genes = function(V,u,prop_genes){
  # Troncature (vers zéro) des éléments trop petit de la matrice de poids.
  ind_mat=1*(abs(V)>u)
  sparse_V=ind_mat*V
  
  # Selection des variables à partir de la matrice d'entraînement X originale.
  freq_poids=unname(apply(ind_mat, 1, function(x) sum(x)))
  tab_poids = data.frame(index=c(1:length(freq_poids)),nb_poids=freq_poids)
  sort_tab_poids = tab_poids[order(tab_poids$nb_poids),]
  selected.var = sort_tab_poids[(nrow(tab_poids)-floor(prop_genes*nrow(tab_poids))):nrow(tab_poids),1]
  return(selected.var)
}

# Fonction applicant la recherche par coordonnées pour régression logistique.
# a: Valeur de départ pour le parametre.
# v: Pourcentage de variance a garder.
# nb_iter: Nombre d'itérations.
# nb_comp: Nombre de composantes maximale.
# pas: Longeur du pas associé au paramètre a.
# train: Ensemble de données.
rpc_borne <- function(a,v,nb_iter,nb_comp,pas,train){
  obj_0=arrayspc(train[,-ncol(train)],para=rep(a,nb_comp),K=nb_comp,use.corr=FALSE,max.iter=100,trace=FALSE,eps=1e-3)
  print("Début:")
  eval_cumul=vector('numeric');eval_cumul[1]=sum(obj_0$pev)
  a_cumul=vector('numeric');a_cumul[1]=a
  pas_cumul=vector('numeric');pas_cumul[1]=pas
  iter=vector('numeric');iter[1]=0
  for(i in 1:nb_iter){
    print(i)
    P=a+pas
    P_ind=1*(P>0)
    #good_index=which(P_ind %in% c(1))
    #bad_index=which(P_ind %in% c(0))
    #eval=vector('numeric')
    if(P_ind==0){eval=Inf}
    if(P_ind==1){
      obj=arrayspc(train[,-ncol(train)],para=rep(P,nb_comp),K=nb_comp,use.corr=FALSE,max.iter=100,trace=FALSE,eps=1e-3)
      eval=sum(obj$pev)
    }
   # if(length(which(eval==min(eval)))>1){dd=sample(which(eval==min(eval)),1)} else{dd=which(eval==min(eval))}
    if(eval<eval_cumul[i] & eval>v){a=P;eval_cumul[i+1]=eval} else{eval_cumul[i+1]=eval_cumul[i];pas=pas/2}
    a_cumul[i+1]=a;iter[i+1]=i
    pas_cumul[i+1]=pas
    print(i)
  }
  param = data.frame(iteration=iter,para=a_cumul,pas_para=pas_cumul,evaluation=eval_cumul)
  return(param)
}

# Fonction applicant la recherche par coordonnées pour se rapprocher de 
# la sparsity recherchée.
# a: Paramètre.
# v: Pourcentage de la variance a conserver
# borne_max: Borne maximal sur la penalite.
# nb_iter: Nombre d'itérations.
# prop_reglog: proportion de variables a conserver pour la reg. log.
# prop_sparsity: Proportion de zeros souhaites dans la matrice de rotation.
# nb_comp: Nombre de composantes maximale.
# pas: Longeur du pas associé au paramètre a.
# train: Ensemble de données.
rpc_vmat <- function(a,v,borne_max,nb_iter,prop_reglog,prop_sparsity,nb_comp,pas,train){
  obj_0=arrayspc(train[,-ncol(train)],para=rep(a,nb_comp),K=nb_comp,use.corr=FALSE,max.iter=100,trace=FALSE,eps=1e-3)
  ACPC=(as.matrix(train[,-ncol(train)]) %*% as.matrix(obj_0$loadings))[,1:cb_comp(obj_0,v)]
  y=train[,ncol(train)]
  training = cbind(ACPC,y)
  
  # Étape 2
  model = bayesglm(as.factor(y) ~.,family=binomial(link='logit'),data=as.data.frame(training))
  coefficients.rl = unname(summary(model)$coefficients[-1,1])
  stand.error.rl = unname(summary(model)$coefficients[-1,2])
  t.statistics.rl = abs(coefficients.rl)
  t.stat.tab = data.frame(x=c(1:length(t.statistics.rl)),t.stat=t.statistics.rl)
  t.stat.tab.order = t.stat.tab[order(t.stat.tab$t.stat),]
  
  # Sélection des variables dans le tableau des statistiques t.
  selected.var.s2 = t.stat.tab.order[(nrow(t.stat.tab)-floor(prop_reglog*nrow(t.stat.tab))):nrow(t.stat.tab),1]
  V_star = obj_0$loadings[,selected.var.s2]
  
  eval_cumul=vector('numeric');eval_cumul[1]=abs((sum(V_star==0)/(nrow(V_star)*ncol(V_star)))-prop_sparsity)
  a_cumul=vector('numeric');a_cumul[1]=a
  pas_cumul=vector('numeric');pas_cumul[1]=pas
  iter=vector('numeric');iter[1]=0
  for(i in 1:nb_iter){
    print(i)
    P=matrix(c(a-pas,a+pas),byrow = T, nrow=1, ncol=2)
    P_ind=1*(P>0)*(P<borne_max)
    good_index=which(P_ind %in% c(1))
    bad_index=which(P_ind %in% c(0))
    eval=vector('numeric')
    if(length(bad_index)>0){for(k in 1:length(bad_index)){eval[bad_index[k]]=Inf}}
    for(j in 1:length(good_index)){
      obj=arrayspc(train[,-ncol(train)],para=rep(P[1,good_index[j]],nb_comp),K=nb_comp,use.corr=FALSE,max.iter=100,trace=FALSE,eps=1e-3)
      ACPC=(as.matrix(train[,-ncol(train)]) %*% as.matrix(obj$loadings))[,1:cb_comp(obj,v)]
      training = cbind(ACPC,y)
      
      # Étape 2
      model = bayesglm(as.factor(y) ~.,family=binomial(link='logit'),data=as.data.frame(training))
      coefficients.rl = unname(summary(model)$coefficients[-1,1])
      t.statistics.rl = abs(coefficients.rl)
      t.stat.tab = data.frame(x=c(1:length(t.statistics.rl)),t.stat=t.statistics.rl)
      t.stat.tab.order = t.stat.tab[order(t.stat.tab$t.stat),]
      
      # Sélection des variables dans le tableau des statistiques t.
      selected.var.s2 = t.stat.tab.order[(nrow(t.stat.tab)-floor(prop_reglog*nrow(t.stat.tab))):nrow(t.stat.tab),1]
      V_star = obj$loadings[,selected.var.s2]
      
      eval[good_index[j]]=abs((sum(V_star==0)/(nrow(V_star)*ncol(V_star)))-prop_sparsity)
    }
    if(length(which(eval==min(eval)))>1){dd=sample(which(eval==min(eval)),1)} else{dd=which(eval==min(eval))}
    if(eval[dd]<eval_cumul[i]){a=P[1,dd];eval_cumul[i+1]=eval[dd]} else{eval_cumul[i+1]=eval_cumul[i];pas=pas/2}
    a_cumul[i+1]=a;iter[i+1]=i
    pas_cumul[i+1]=pas
    print("Fin")
  }
  param = data.frame(iteration=iter,para=a_cumul,pas_para=pas_cumul,evaluation=eval_cumul)
  return(param)
}



####################################################
############ Algorithme SELECT() ###################
####################################################


# Action: Exporte un tableau vers un dossier choisi (necessute arm).
# dataframe: Tableau de donnees necessitant la selection de variables (exclure y).
# y: Vecteur de la variable de reponse (pour train).
# v: Proportion de la variance expliquee que l'on conserve (ACP)
# prop_reglog: Proportion des composantes a garder apres la regression logistique.
# prop_sparse: Proportion souhaite d'elements nulle dans la matrice de rotation.
# prop_genes: Pourcentage de genes a conserver
SELECT = function(train,valid,test,v,prop_reglog,prop_sparse,prop_genes){
  ## Étape 1 ##
  # Application de l'ACP 
  expr.prcomp <- prcomp(train[,-ncol(train)],cor=TRUE)
  PCA=expr.prcomp$x
  V=expr.prcomp$rotation
  
  # Determination de q (nombre de variables à conserver) 
  var.per.pc <- (expr.prcomp$sdev)^2
  var.per.pc.percent <- var.per.pc/sum(var.per.pc)
  cumvar=numeric()
  for(i in 1:nrow(train)){cumvar[i] = sum(var.per.pc[1:i])/sum(var.per.pc)}
  cumvar_ind=as.numeric(cumvar<v)
  q=sum(cumvar_ind)+1
  Q = PCA[,1:q]
  
  
  ## Etape 2 ##
  # Application de la régression bayésienne et ordonnement des statistiques t.
  y=train[,ncol(train)]
  training = cbind(Q,y)
  model = bayesglm(as.factor(y) ~.,family=binomial(link='logit'),data=as.data.frame(training))
  coefficients.rl = unname(summary(model)$coefficients[-1,1])
  mag.coefficients = abs(coefficients.rl)
  coef.tab = data.frame(x=c(1:length(mag.coefficients)),mag.coef=mag.coefficients)
  coef.tab.order = coef.tab[order(coef.tab$mag.coef),]
  
  # Sélection des variables dans le tableau des statistiques t.
  selected.var.lr = coef.tab.order[(nrow(coef.tab)-floor(prop_reglog*nrow(coef.tab))):nrow(coef.tab),1]
  d=length(selected.var.lr)
  
  # Reconfiguration des matrices Q (composantes) et V (matrice de rotation).
  Q1 = Q[,selected.var.lr]
  V1 = V[,selected.var.lr]
  
  
  ## Etape 3 ##
  # Sélection des genes les plus informatifs
  u=u_sparse(V1,2000,prop_sparse)
  genes_inf=trouve_genes(V1,u,prop_genes)
  X=train[,genes_inf]
  
  
  ## Etape 4 ##
  # Appliquer l'ACP sur l'ensemble d'entraînement.
  pca_train <- prcomp(X, retx=TRUE, center=TRUE, scale=TRUE)
  Q2 <- pca_train$x
  train_PCA = as.data.frame(cbind(Q2,y))
  
  # Appliquer l'ACP sur l'ensemble de validation.
  Q_valid <- predict(pca_train, newdata=valid[,genes_inf])
  y=valid[,ncol(valid)]
  valid_PCA=as.data.frame(cbind(Q_valid,y))
  
  # Appliquer l'ACP sur l'ensemble test.
  Q_test <- predict(pca_train, newdata=test[,genes_inf])
  y=test[,ncol(test)]
  test_PCA=as.data.frame(cbind(Q_test,y))
  
  return(list(train_PCA,valid_PCA,test_PCA))
}


######################################################
############ Algorithme SELECT 2() ###################
######################################################


# Action: Exporte un tableau vers un dossier choisi (necessite arm).
# dataframe: Tableau de donnees necessitant la selection de variables (exclure y).
# y: Vecteur de la variable de reponse (pour train).
# v: Proportion de la variance expliquee que l'on conserve (ACP)
# prop_reglog: Proportion des composantes a garder apres la regression logistique.
# prop_sparse: Proportion souhaite d'elements nulle dans la matrice de rotation.
# prop_genes: Pourcentage de genes a conserver
# pas: Pas pour l'optimisation de lambda.
SELECT2 = function(train,valid,test,v,a,nb_iter_1,nb_iter_2,pas1,pas2,prop_reglog,prop_sparse,prop_genes){
  ## Étape 1 ##
  # Application de l'ACPC
  tab_borne=rpc_borne(a,v,nb_iter_1,nrow(train),pas1,train)
  print(tab_borne)
  borne_maximal=tab_borne[nrow(tab_borne),2]
  var_retenu=tab_borne[nrow(tab_borne),4]
  #print(paste("borne_maximal:",borne_maximal," et variance_retenue:",var_retenu,sep=""))
  tab_opt=rpc_vmat(0.75*borne_maximal,v,borne_maximal,nb_iter_2,prop_reglog,prop_sparse,nrow(train),pas2,train)
  print(tab_opt)
  val_opt= tab_opt[nrow(tab_opt),2]
  
  print("Début de L'ACPC (etape 1)")
  p=arrayspc(train[,-ncol(train)],para=rep(val_opt,nrow(train)),K=nrow(train),use.corr=FALSE,max.iter=100,trace=FALSE,eps=1e-3)
  ACPC=(as.matrix(train[,-ncol(train)]) %*% as.matrix(p$loadings))[,1:cb_comp(p,v)]
  V=p$loadings
  
  ## Etape 2 ##
  # Application de la régression bayésienne et ordonnement des statistiques t.
  print("Début de l'étape 2")
  y=train[,ncol(train)]
  training = cbind(ACPC,y)
  model = bayesglm(as.factor(y) ~.,family=binomial(link='logit'),data=as.data.frame(training))
  coefficients.rl = unname(summary(model)$coefficients[-1,1])
  t.statistics.rl = abs(coefficients.rl)
  t.stat.tab = data.frame(x=c(1:length(t.statistics.rl)),t.stat=t.statistics.rl)
  t.stat.tab.order = t.stat.tab[order(t.stat.tab$t.stat),]
  selected.var.s2 = t.stat.tab.order[(nrow(t.stat.tab)-floor(prop_reglog*nrow(t.stat.tab))):nrow(t.stat.tab),1]
  V_star = p$loadings[,selected.var.s2] 
  print("Fin étape 2")
  
  ## Etape 3 ##
  # Sélection des genes les plus informatifs
  print("Debut de l'étape 3")
  genes_inf=trouve_genes(V_star,0.00000001,prop_genes)
  X=train[,genes_inf]
  print("Fin l'étape 3")
  
  ## Etape 4 ##
  # Appliquer l'ACP sur l'ensemble d'entraînement.
  print("Debut de l'étape 4")
  pca_train <- prcomp(X, retx=TRUE, center=TRUE, scale=TRUE)
  Q2 <- pca_train$x
  train_PCA = as.data.frame(cbind(Q2,y))
  
  # Appliquer l'ACP sur l'ensemble de validation.
  Q_valid <- predict(pca_train, newdata=valid[,genes_inf])
  y=valid[,ncol(valid)]
  valid_PCA=as.data.frame(cbind(Q_valid,y))
  
  # Appliquer l'ACP sur l'ensemble test.
  Q_test <- predict(pca_train, newdata=test[,genes_inf])
  y=test[,ncol(test)]
  test_PCA=as.data.frame(cbind(Q_test,y))
  
  print("Fin étape 4")
  
  return(list(train_PCA,valid_PCA,test_PCA))
}

# Fonction trouvant le nombre de composantes pour obtenir un seuil
# objet: Objet de type arrayspc
# seuil: Le seuil à atteindre
cb_comp <- function(objet,seuil){
  pev_cumul=numeric()
  for(i in 1:116){pev_cumul[i]=sum(objet$pev[1:i])}
  return(sum(pev_cumul<seuil)+1)
}

#######################################################
############ Algorithme SELECT 3 () ###################
#######################################################


# Action: Exporte un tableau vers un dossier choisi (necessute arm).
# dataframe: Tableau de donnees necessitant la selection de variables (exclure y).
# y: Vecteur de la variable de reponse (pour train).
# v: Proportion de la variance expliquee que l'on conserve (ACP)
# seed_boruta: Une seed pour pouvoir reproduire boruta.
# prop_sparse: Proportion souhaite d'elements nulle dans la matrice de rotation.
# prop_genes: Pourcentage de genes a conserver
SELECT3 = function(train,valid,test,v,seed_boruta,prop_sparse,prop_genes){
  ## Etape 1 ##
  # Application de l'ACP 
  expr.prcomp <- prcomp(train[,-ncol(train)],cor=TRUE)
  PCA=expr.prcomp$x
  V=expr.prcomp$rotation
  
  # Determination de q (nombre de variables à conserver) 
  var.per.pc <- (expr.prcomp$sdev)^2
  var.per.pc.percent <- var.per.pc/sum(var.per.pc)
  cumvar=numeric()
  for(i in 1:nrow(train)){cumvar[i] = sum(var.per.pc[1:i])/sum(var.per.pc)}
  cumvar_ind=as.numeric(cumvar<v)
  q=sum(cumvar_ind)+1
  Q = PCA[,1:q]
  
  
  ## Etape 2 ##
  # Application de la régression bayésienne et ordonnement des statistiques t.
  y=train[,ncol(train)]
  training = as.data.frame(cbind(Q,y))
  boruta.train <- Boruta(y~., data = training, maxRuns = 1000,doTrace = 2)
  final.boruta <- TentativeRoughFix(boruta.train)
  selected.var.boruta <- which(unname(final.boruta$finalDecision) %in% c("Confirmed"))
  d=length(selected.var.boruta)
  
  # Reconfiguration des matrices Q (composantes) et V (matrice de rotation).
  Q1 = Q[,selected.var.boruta]
  V1 = V[,selected.var.boruta]
  
  
  ## Etape 3 ##
  # Sélection des genes les plus informatifs
  u=u_sparse(V1,2000,prop_sparse)
  genes_inf=trouve_genes(V1,u,prop_genes)
  X=train[,genes_inf]
  
  
  ## Etape 4 ##
  # Appliquer l'ACP sur l'ensemble d'entraînement.
  pca_train <- prcomp(X, retx=TRUE, center=TRUE, scale=TRUE)
  Q2 <- pca_train$x
  train_PCA = as.data.frame(cbind(Q2,y))
  
  # Appliquer l'ACP sur l'ensemble de validation.
  Q_valid <- predict(pca_train, newdata=valid[,genes_inf])
  y=valid[,ncol(valid)]
  valid_PCA=as.data.frame(cbind(Q_valid,y))
  
  # Appliquer l'ACP sur l'ensemble test.
  Q_test <- predict(pca_train, newdata=test[,genes_inf])
  y=test[,ncol(test)]
  test_PCA=as.data.frame(cbind(Q_test,y))
  
  return(list(train_PCA,valid_PCA,test_PCA))
}


######################################################
############ Fonctions d'optimisation ################
######################################################

# Fonction applicant la recherche par coordonnées.
# a1: Valeur initiale du premier parametre.
# a2: Valeur initiale du deuxieme parametre.
# nb_iter: Nombre d'iterations dans la recherche par coordonnees.
# pas1: Longueur de pas du premier parametre.
# pas2: Longueur de pas du deuxieme parametre.
# h2o_train: Ensemble d'entrainement (transformé en format h2o).
# h2o_valid: Ensemble de validation (transformé en format h2o).
rpc <- function(a1,a2,nb_iter,pas1,pas2,h2o_train,h2o_valid){
  obj_0=h2o.glm(y="y",x=colnames(h2o_train)[-ncol(h2o_train)],training_frame=h2o_train,validation_frame=h2o_valid,family="binomial",alpha=a1,lambda=a2)
  eval_cumul=vector('numeric');eval_cumul[1]=(h2o.performance(obj_0,h2o_valid))@metrics$AUC
  a1_cumul=vector('numeric');a2_cumul=vector('numeric');a1_cumul[1]=a1;a2_cumul[1]=a2
  pas1_cumul=vector('numeric');pas2_cumul=vector('numeric');pas1_cumul[1]=pas1;pas2_cumul[1]=pas2
  iter=vector('numeric');iter[1]=0
  for(i in 1:nb_iter){
    P=matrix(c(a1, a2+pas2, a1+pas1, a2, a1, a2-pas2, a1-pas1, a2),byrow = T, nrow=4, ncol=2)
    P_ind=1*(P>0)*(unname(cbind(P[,1],rep(0,nrow(P)))<1))
    V_ind=1*(rowSums(P_ind)==2)
    good_index=which(V_ind %in% c(1))
    bad_index=which(V_ind %in% c(0))
    eval=vector('numeric')
    if(length(bad_index)>0){for(k in 1:length(bad_index)){eval[bad_index[k]]=-Inf}}
    for(j in 1:length(good_index)){
      obj=h2o.glm(y="y",x=colnames(h2o_train)[-ncol(h2o_train)],training_frame=h2o_train,validation_frame=h2o_valid,family="binomial",alpha=P[good_index[j],1],lambda=P[good_index[j],2])
      perf=h2o.performance(obj,h2o_valid)
      eval[good_index[j]]=perf@metrics$AUC
    }
    if(length(which(eval==max(eval)))>1){dd=sample(which(eval==max(eval)),1)} else{dd=which(eval==max(eval))}
    if(eval[dd]>eval_cumul[i]){a1=P[dd,1];a2=P[dd,2];eval_cumul[i+1]=eval[dd]} else{eval_cumul[i+1]=eval_cumul[i];pas1=pas1/2;pas2=pas2/2}
    a1_cumul[i+1]=a1;a2_cumul[i+1]=a2;iter[i+1]=i
    pas1_cumul[i+1]=pas1;pas2_cumul[i+1]=pas2
  }
  param = data.frame(iteration=iter,alpha=a1_cumul,lambda=a2_cumul,pas_alpha=pas1_cumul,pas_lambda=pas2_cumul,evaluation=eval_cumul)
  return(param)
}

# Fonction applicant une analyse de sensibilite pour des valeurs de alpha et lambda.
# alpha_set: Palette de valeurs de alpha.
# lambda_set: Palette de valeurs de lambda.
# algo: Type d'algorithme utilisé. ("reg_log","svm_lin","svm_gauss")
# nb_iter: Nombre d'iterations dans la fonction de recherche par coordonnees.
# pas1: Longueur du pas pour alpha.
# pas2: Denominateur du pas pour lambda. (lambda_set[j]/pas2)
# train: Ensemble d'entraînement (sous format h2o si "reg_log")
# valid: Ensemble de validation (sous format h2o si "reg_log")
anal_sens <- function(alpha_set,lambda_set,algo,nb_iter,pas1,pas2,train,valid){
models=list()
plr_matrix = matrix(, nrow = length(alpha_set), ncol = length(lambda_set))
for(i in 1:length(alpha_set)){
  for(j in 1:length(lambda_set)){
    if (algo=="reg_log") {
      recherche=rpc(alpha_set[i],lambda_set[j],nb_iter,pas1,lambda_set[j]/pas2,train,valid);x=6
    } else if (algo=="svm_lin") {
      recherche=rpc_lin(lambda_set[j],nb_iter,lambda_set[j]/pas2,train,valid);x=4
    } else {
      recherche=rpc_svm(alpha_set[i],lambda_set[j],nb_iter,alpha_set[i]/pas1,lambda_set[j]/pas2,train,valid);x=6
    }
    models[[((i-1)*length(lambda_set))+j]]=recherche
    plr_matrix[i,j]=recherche[16,x]
  }
}
models[[length(alpha_set)*length(lambda_set)+1]]=plr_matrix
return(models)
}

# Fonction applicant la recherche par coordonnées pour le SVM avec noyau gaussien.
# a1: Valeur initiale du premier hyperparametre.
# a2: Valeur initiale du deuxieme hyperparametre.
# nb_iter: Nombre d'itérations
# pas 1: Pas pour le premier hyperparametre
# pas2: Pas pour le deuxieme hyperparametre
# train: Ensemble d'entrainement
# valid: Ensemble de validation
rpc_svm <- function(a1,a2,nb_iter,pas1,pas2,train,valid){
  svm_0=svm(y ~ ., data=train,type='C-classification', probability=TRUE,scale=FALSE,cost=a1,gamma=a2,kernel="radial")
  eval_cumul=vector('numeric');
  eval_cumul[1]=auc(valid[,ncol(valid)], unname(attr(predict(svm_0,valid[,-ncol(valid)],probability=TRUE), "probabilities")[,1]))
  
  a1_cumul=vector('numeric'); a2_cumul=vector('numeric')
  a1_cumul[1]=a1; a2_cumul[1]=a2
  
  pas1_cumul=vector('numeric'); pas2_cumul=vector('numeric');
  pas1_cumul[1]=pas1; pas2_cumul[1]=pas2
  
  iter=vector('numeric');iter[1]=0
  
  for(i in 1:nb_iter){
    P=matrix(c(a1, a2+pas2, a1+pas1, a2, a1, a2-pas2, a1-pas1, a2),byrow = T, nrow=4, ncol=2)
    P_ind=1*(P>0)
    V_ind=1*(rowSums(P_ind)==2)
    good_index=which(V_ind %in% c(1))
    bad_index=which(V_ind %in% c(0))
    eval=vector('numeric')
    if(length(bad_index)>0){for(k in 1:length(bad_index)){eval[bad_index[k]]=-Inf}}
    for(j in 1:length(good_index)){
      obj=svm(y ~ ., data=train,type='C-classification',probability=TRUE,scale=FALSE,cost=P[good_index[j],1],gamma=P[good_index[j],2])
      eval[good_index[j]]=auc(valid[,ncol(valid)], unname(attr(predict(obj,valid[,-ncol(valid)],probability=TRUE), "probabilities")[,1]))
    }
    if(length(which(eval==max(eval)))>1){dd=sample(which(eval==max(eval)),1)} else{dd=which(eval==max(eval))}
    if(eval[dd]>eval_cumul[i]){a1=P[dd,1];a2=P[dd,2];eval_cumul[i+1]=eval[dd]} else{eval_cumul[i+1]=eval_cumul[i];pas1=pas1/2;pas2=pas2/2}
    a1_cumul[i+1]=a1;a2_cumul[i+1]=a2;iter[i+1]=i
    pas1_cumul[i+1]=pas1;pas2_cumul[i+1]=pas2
  }
  param = data.frame(iteration=iter,cout=a1_cumul,gamma=a2_cumul,pas_cout=pas1_cumul,pas_gamma=pas2_cumul,evaluation=eval_cumul)
  return(param)
}

# Fonction applicant la recherche par coordonnées pour le SVM avec noyau linéaire.
# a1: Valeur initiale de l'hyperparametre.
# nb_iter: Nombre d'iterations.
# pas1: Longueur de pas de l'hyperparametre.
# train: Ensemble d'entrainement.
# valid: Ensemble de validation.
rpc_lin <- function(a1,nb_iter,pas1,train,valid){
  svm_0=svm(y ~ ., data=train,type='C-classification', probability=TRUE,scale=FALSE,cost=a1,kernel="linear")
  eval_cumul=vector('numeric');
  eval_cumul[1]=auc(valid[,ncol(valid)], unname(attr(predict(svm_0,valid[,-ncol(valid)],probability=TRUE), "probabilities")[,1]))
  
  a1_cumul=vector('numeric'); a1_cumul[1]=a1; 
  pas1_cumul=vector('numeric'); pas1_cumul[1]=pas1; 
  iter=vector('numeric');iter[1]=0
  
  for(i in 1:nb_iter){
    P=c(a1-pas1, a1+pas1)
    P_ind=1*(P>0)
    good_index=which(P_ind %in% c(1))
    bad_index=which(P_ind %in% c(0))
    eval=vector('numeric')
    if(length(bad_index)>0){for(k in 1:length(bad_index)){eval[bad_index[k]]=-Inf}}
    for(j in 1:length(good_index)){
      obj=svm(y ~ ., data=train,type='C-classification',probability=TRUE,scale=FALSE,cost=P[good_index[j]],kernel="linear")
      eval[good_index[j]]=auc(valid[,ncol(valid)], unname(attr(predict(obj,valid[,-ncol(valid)],probability=TRUE), "probabilities")[,1]))
    }
    if(length(which(eval==max(eval)))>1){dd=sample(which(eval==max(eval)),1)} else{dd=which(eval==max(eval))}
    if(eval[dd]>eval_cumul[i]){a1=P[dd];eval_cumul[i+1]=eval[dd]} else{eval_cumul[i+1]=eval_cumul[i];pas1=pas1/2}
    a1_cumul[i+1]=a1;iter[i+1]=i
    pas1_cumul[i+1]=pas1
  }
  param = data.frame(iteration=iter,cout=a1_cumul,pas_cout=pas1_cumul,evaluation=eval_cumul)
  return(param)
}


# Fonction trouvant le meilleur couple (alpha,lambda) a la suite d'une analyse de sensibilite.
# alpha_set: Palette de valeurs de alpha.
# lambda_set: Palette de valeurs de lambda.
# mat_sens: Matrice de sensibilite.
meilleur_couple <- function(alpha_set,lambda_set,sens_obj){
  mat_sens=sens_obj[[length(sens_obj)]]
  AUC=max(mat_sens)
  tab_maximum=which(mat_sens == max(mat_sens), arr.ind = TRUE)
  if(nrow(tab_maximum)==1){
    ind_ligne=tab_maximum[1,1]
    ind_col=tab_maximum[1,2]
  } else{
    penalite=numeric()
    for(i in 1:nrow(tab_maximum)){penalite[i]=abs(alpha_set[tab_maximum[i,1]])+abs(lambda_set[tab_maximum[i,2]])}
    tab_maximum=cbind(tab_maximum,penalite)
    tab_maximum_order = tab_maximum[order(tab_maximum[,ncol(tab_maximum)]),]
    ind_ligne=tab_maximum_order[1,1]
    ind_col=tab_maximum_order[1,2]
  }
  alpha=sens_obj[[(ind_ligne-1)*length(lambda_set)+ind_col]][nrow(sens_obj[[(ind_ligne-1)*length(lambda_set)+ind_col]]),2]
  lambda=sens_obj[[(ind_ligne-1)*length(lambda_set)+ind_col]][nrow(sens_obj[[(ind_ligne-1)*length(lambda_set)+ind_col]]),3]
  return(c(alpha,lambda,AUC))
}


###############################################
############ RLP: Optimisation ################
###############################################

# Action: Effectue l'optimisation des hyperparametres avec la configuration par defaut.
# train: Ensemble d'entrainement (format h2o).
# valid: Ensemble de validation(format h2o).
RLP_proc_aut = function(train,valid){
  binomial.fit=h2o.glm(y="y",x=colnames(train)[-ncol(train)],training_frame=train,validation_frame=valid,family="binomial",lambda_search = TRUE)
  alpha=binomial.fit@allparameters$alpha
  lambda=binomial.fit@model$lambda_best
  AUC= binomial.fit@model$validation_metrics@metrics$AUC
  return(c(alpha,lambda,AUC))
}

# Action: Effectue l'optimisation des hyperparametres avec la configuration 
#         recommandee par H2o.
# alpha_set: Palette de valeurs pour alpha.
# train: Ensemble d'entrainement (format h2o).
# valid: Ensemble de validation(format h2o).
# test: Ensemble de test (format h2o).
RLP_proc_rec = function(alpha_set,train,valid,test){
  models=list()
  resultats=vector('double')
  for(i in 1:length(alpha_set)){
    models[[i]]=h2o.glm(y="y",x=colnames(train)[-ncol(train)],training_frame=train,validation_frame=valid,family="binomial",alpha = alpha_set[i],lambda_search = TRUE)
    alpha=models[[i]]@allparameters$alpha
    lambda=models[[i]]@model$lambda_best
    AUC=models[[i]]@model$validation_metrics@metrics$AUC
    resultats=rbind(resultats,c(alpha,lambda,AUC))
  }
  resultats=resultats[order(resultats[,ncol(resultats)]),]
  return(resultats)
}

###############################################
############ MVS: Optimisation ################
###############################################

##############################################
############ MGB:optimisation ################
##############################################

# Action: Effectue l'optimisation des hyperparametres avec la configuration par defaut.
# train: Ensemble d'entrainement (format h2o).
# valid: Ensemble de validation(format h2o).
# test: Ensemble de test (format h2o).
MGB_proc_aut = function(train,valid,test){
  gbm.model.df <- h2o.gbm(y = "y", x = colnames(train)[-ncol(train)],distribution="bernoulli",training_frame = train,
                          validation_frame = valid)
  learn_rate=gbm.model.df@allparameters$learn_rate
  max_depth=gbm.model.df@allparameters$max_depth
  ntrees=gbm.model.df@allparameters$ntrees
  AUC=gbm.model.df@model$validation_metrics@metrics$AUC
  return(c(learn_rate,max_depth,ntrees,AUC))
}

# Action: Effectue l'optimisation des hyperparametres avec la recherche par grille
#         (favorise un modele avec peu d'arbres)
# train: Ensemble d'entrainement. (format h2o)
# valid: Ensemble de validation. (format h2o)
# test: Ensemble de test. (format h2o)
# method: Methode d'optimisation utilisee ("random" ou "grid")
MGB_proc_rpg_rs = function(train,valid,test,method,ntrees_set,maxdepth_set,learnrate_set){
  #  Cartesian Grid Search
  hyper_parameters <- list(ntrees=ntrees_set,max_depth=maxdepth_set, learn_rate=learnrate_set)
  if(method=="grid"){grid=h2o.grid("gbm", hyper_params = hyper_parameters,y = "y", x = colnames(train)[-ncol(train)], distribution="bernoulli",
                            training_frame = train, validation_frame = valid)
  } else {search_criteria=list(strategy="RandomDiscrete",max_models=75,max_runtime_secs=1000,seed=1)
  grid=h2o.grid("gbm",hyper_params=hyper_parameters,search_criteria=search_criteria,y = "y", x = colnames(train)[-ncol(train)], distribution="bernoulli",
      training_frame = train, validation_frame = valid)
  }
 
  # Express the best model
  grid_models <- lapply(grid@model_ids, function(model_id) { model = h2o.getModel(model_id) })
  list_auc_valid=numeric()
  for (i in 1:length(grid_models)){list_auc_valid[i]=h2o.auc(grid_models[[i]],valid=TRUE)}
  ind=1*(list_auc_valid==max(list_auc_valid))
  pos_max=which(ind %in% c(1))
  if(length(pos_max)==1){
    gbm.model.tuned <- grid_models[[pos_max]]
  } else{
    nb_arbres=vector()
    for(i in 1:length(pos_max)){nb_arbres[i]=grid_models[[pos_max[i]]]@allparameters$ntrees}
    ind=1*(-nb_arbres==max(-nb_arbres))
    pos_arbres=which(ind %in% c(1))
    if(length(pos_arbres)==1){
      gbm.model.tuned <- grid_models[[pos_max[pos_arbres]]]
    } else{
        gbm.model.tuned <- grid_models[[pos_max[sample(pos_arbres,1)]]]}
  }
  
  learn_rate=gbm.model.tuned@allparameters$learn_rate
  max_depth=gbm.model.tuned@allparameters$max_depth
  ntrees=gbm.model.tuned@allparameters$ntrees
  AUC=gbm.model.tuned@model$validation_metrics@metrics$AUC
  
  return(c(learn_rate,max_depth,ntrees,AUC))
}

################################################################################
############ Meilleures performances et évolution d'algorithmes ################
################################################################################

# Action: Construit la table (selon les choix d'arguments) qui sera anlaysé pour  
#         évaluer la performance des méthodes d'optimisation (algorithme et classificateur donnés).
# basic_path: Chemin vers le dossier général des resultats
# classif: Nom du classificateur. ("MGB","MVS" ou "RLP")
# algo: Algorithme de sélection de variables (cas1) ("SELECT1","SELECT2","SELECT3").
import_perf = function(basic_path,classif,algo){
    noms=Import(paste(paste(basic_path,"/",classif,"/",algo,sep=""),sep=""),"*.csv")
    tableaux=list()
    methode=numeric()
    bloc=numeric()
    AUC=numeric()
    noms_net=gsub('.{4}$', '', noms)
    for(j in 1:length(noms_net)){
      tableaux[[j]]=get(noms[j])
      AUC=c(AUC,as.numeric(as.vector(tableaux[[j]][,ncol(tableaux[[j]])])))
      bloc=c(bloc,1:nrow(tableaux[[j]]))
      methode=c(methode,rep(noms_net[j],nrow(tableaux[[j]])))
    } 
  D=data.frame(methode,bloc,AUC)
  D$methode=as.factor(D$methode)
  D$bloc=as.factor(D$bloc)
  return(D)
}

# Action: Fonction retournant les graphiques des résidus d'une ANOVA à blocs complets
# tab: Tableau pour faire l'ANOVA à blocs complets
# P.S: On suppose que tab est composée de trois colonnes: AUC, bloc et methode.
residus_graphiques = function(tab){
  tab$methode=as.factor(tab$methode)
  tab$bloc=as.factor(tab$bloc)
  aov0=aov(AUC~bloc+methode,data=tab)
  par(mfrow=c(2,2))
  residus=residuals(aov0)
  qqnorm(residus,xlab="Quantiles théoriques",ylab="Quantiles d'échantillon",main="Graphique quantiles-quantiles")
  qqline(residus)
  plot(as.numeric(tab$methode),residus,xlab="Méthode",ylab="Résidus")
  abline(h=0)
  plot(as.numeric(tab$bloc),residus,xlab="Bloc",ylab="Résidus")
  abline(h=0)
  plot(fitted(aov0),residus,xlab="Valeurs prévues",ylab="Résidus")
  abline(h=0)
  par(mfrow=c(1,1))
}

# Action: Evalue la performance d'un modele selon une methode d'optimisation
# basic_path: Chemin vers le dossier contenant les diverses données.
# algo_num: Algorithme de sélection de variables (1,2 ou 3)
# classif: Classificateur.
# methode: Méthode d'optimisation à utiliser pour évaluer les performances.
# pref: Nom commun des dossiers à parcourir.
# k: Graine pour reproductibilité.
performances = function(basic_path,algo_num,classif,methode,k){
  resultats=read.csv(paste(basic_path,"/resultats/",classif,"/SELECT",algo_num,"/",methode,".csv",sep = ""), sep=",",header = T)
  nb_exp=length(list.dirs(path=basic_path,recursive = FALSE))-2
  mesures_perf=numeric();
  for(i in 1:nb_exp){
    train=read.csv(paste(basic_path,"/exp",i,"/Transformed_",algo_num,"/train_PCA_",algo_num,"_",i,".csv",sep = ""), sep=",",header = T)
    valid=read.csv(paste(basic_path,"/exp",i,"/Transformed_",algo_num,"/valid_PCA_",algo_num,"_",i,".csv",sep = ""), sep=",",header = T)
    test=read.csv(paste(basic_path,"/exp",i,"/Transformed_",algo_num,"/test_PCA_",algo_num,"_",i,".csv",sep = ""), sep=",",header = T)
    #noms_hyperparam=colnames(resultats)[-length(colnames(resultats))]
    if(classif=="MGB"){
      h2o_train=as.h2o(train)
      h2o_valid=as.h2o(valid)
      h2o_test=as.h2o(test)
      h2o_train$y=as.factor(h2o_train$y)
      h2o_valid$y=as.factor(h2o_valid$y)
      h2o_test$y=as.factor(h2o_test$y)
      gbm.model.df<-h2o.gbm(y = "y", x = colnames(train)[-ncol(train)],distribution="bernoulli",training_frame=h2o_train,learn_rate=resultats[i,1],
                            max_depth = resultats[i,2],ntrees = resultats[i,3],validation_frame=h2o_valid)
      perf=h2o.performance(gbm.model.df,h2o_test)
      conf_mat=h2o.confusionMatrix(perf)
      prec = (conf_mat[1,1]+conf_mat[2,2])/(conf_mat[1,1]+conf_mat[1,2]+conf_mat[2,1]+conf_mat[2,2])
      AUC = perf@metrics$AUC
      mesures_perf=rbind(mesures_perf,c(AUC,prec))
     }else if(classif=="RLP") {
      h2o_train=as.h2o(train)
      h2o_valid=as.h2o(valid)
      h2o_test=as.h2o(test)
      h2o_train$y=as.factor(h2o_train$y)
      h2o_valid$y=as.factor(h2o_valid$y)
      h2o_test$y=as.factor(h2o_test$y)
      binomial.fit=h2o.glm(y="y",x=colnames(train)[-ncol(train)],training_frame=h2o_train,validation_frame=h2o_valid,family="binomial",alpha=resultats[i,1],lambda=resultats[i,2])
      perf=h2o.performance(binomial.fit,h2o_test)
      conf_mat=h2o.confusionMatrix(perf)
      prec = (conf_mat[1,1]+conf_mat[2,2])/(conf_mat[1,1]+conf_mat[1,2]+conf_mat[2,1]+conf_mat[2,2])
      AUC = perf@metrics$AUC
      mesures_perf=rbind(mesures_perf,c(AUC,prec))
     } else{
      set.seed(k);
      if(methode=="nl"){
         svm.fit=svm(y ~ ., data=train,type='C-classification',kernel="linear",cost=resultats[i,1],probability=TRUE,scale=FALSE)
       } else{
         svm.fit=svm(y ~ ., data=train,type='C-classification', probability=TRUE,scale=FALSE,cost=resultats[i,2],gamma=resultats[i,1],kernel="radial")
       }
       pred_test<- predict(svm.fit,test[,-ncol(test)],probability=TRUE)
       proba_pred=attr(pred_test, "probabilities")
       conf_mat=confusionMatrix(unname(pred_test), test$y)$table
       prec = (conf_mat[1,1]+conf_mat[2,2])/(conf_mat[1,1]+conf_mat[1,2]+conf_mat[2,1]+conf_mat[2,2])
       AUC = as.numeric(auc(test$y, unname(attr(pred_test, "probabilities")[,1])))
       mesures_perf=rbind(mesures_perf,c(AUC,prec))
    }
  }
  colnames(mesures_perf)=c("AUC","precision")
  return(mesures_perf)
}

# Action: Retourne le tableau pour l'ANOVA de l'évolution d'une méthode d'optimisation.
# basic_path: Chemin vers le dossier contenant les diverses données. 
# classif: Classificateur utilisé.
# methode: Méthode d'optimisation analysée. 
# k: Graine de reproductibilite
ANOVA_evol_algo = function(basic_path,classif,methode,k){
  tab1=performances(basic_path,1,classif,methode,k)
  tab2=performances(basic_path,2,classif,methode,k)
  tab3=performances(basic_path,3,classif,methode,k)
  ANOVA = data.frame(rbind(tab1,tab2,tab3),c(1:nrow(tab1),1:nrow(tab1),1:nrow(tab1)),c(rep("SELECT1",nrow(tab1)),rep("SELECT2",nrow(tab1)),rep("SELECT3",nrow(tab1))))
  colnames(ANOVA)=c("AUC","precision","bloc","algo")
  return(ANOVA)
}