# Nom: Module d'optimisation des hyperparametres et de la creation des modeles.
# Auteur: Louis-Marc Mercier
# Date: 22 juillet 2017

# Le but de ce programme est d'optimiser les hyperparametres de chacun des 3 modeles.
# Puis, on retourne les résultats et les valeurs des hyperparametres dans le bon dossier.

######################################################################
########## Module: Optimisation des classificateurs ##################
######################################################################

basic_path = "C:/Users/Louis-Marc/Desktop/SELECT/data"


for(j in 1:3){
  # Resultats RLP (pdf: par defaut, rcp: recherche par coordonnees, r: recommandation)
  resultats_rlp_pd=vector('double')
  resultats_rlp_rpc=vector('double')
  resultats_rlp_r=vector('double')
  
  # Resultats MVS ( rpc_nl: recherche par coordonnees avec noyau lineaire
  #                , rcp_ng: recherche par coordonnees avec noyau gaussien)
  resultats_mvs_rpc_nl=vector('double')
  resultats_mvs_rpc_ng=vector('double')
  
  # Resultats GBM (pd: par defaut, rpg: recherche par grille, ra: recherche aleatoire)
  resultats_gbm_pd=vector('double')
  resultats_gbm_rpg=vector('double')
  resultats_gbm_ra=vector('double')
  for(i in 1:10){
  #h2o.init()
  noms=Import(paste(paste(basic_path,"/exp",i,sep=""),"/Transformed_",j,sep=""),"*.csv")
  test=get(noms[1])
  train=get(noms[2])
  valid=get(noms[3])
  rm(list=noms)
  
  # Transformation sous le format h2o (pour RLP et MGB)
  h2o_train=as.h2o(train)
  h2o_valid=as.h2o(valid)
  h2o_test=as.h2o(test)
  h2o_train$y=as.factor(h2o_train$y)
  h2o_valid$y=as.factor(h2o_valid$y)
  h2o_test$y=as.factor(h2o_test$y)  
  
  ## Optimisation ##
  
   # Optimisations pour RLP #
   resultats_rlp_pd=rbind(resultats_rlp_pd,RLP_proc_aut(h2o_train,h2o_valid))
   
   ANALYSE_1=anal_sens(c(0.20,0.40,0.60,0.80),c(2^(-5),2^(-3),2^(-1),2^(1),2^(3),2^(5)),"reg_log",15,0.15,3,h2o_train,h2o_valid)
   ANALYSE_2=anal_sens(c(0.20,0.40,0.60,0.80),c(2^(-5),2^(-3),2^(-1),2^(1),2^(3),2^(5)),"reg_log",15,0.15,2,h2o_train,h2o_valid)
   ANALYSE_3=anal_sens(c(0.20,0.40,0.60,0.80),c(2^(-5),2^(-3),2^(-1),2^(1),2^(3),2^(5)),"reg_log",15,0.10,3,h2o_train,h2o_valid)
   ANALYSE_4=anal_sens(c(0.20,0.40,0.60,0.80),c(2^(-5),2^(-3),2^(-1),2^(1),2^(3),2^(5)),"reg_log",15,0.15,2,h2o_train,h2o_valid)
   ANALYSES=list(ANALYSE_1,ANALYSE_2,ANALYSE_3,ANALYSE_4)
   AUC_ANALYSES=c(max(ANALYSE_1[[length(ANALYSE_1)]]),max(ANALYSE_2[[length(ANALYSE_2)]]),max(ANALYSE_3[[length(ANALYSE_3)]]),max(ANALYSE_4[[length(ANALYSE_4)]]))
   AUC_pos_max=which(AUC_ANALYSES == max(AUC_ANALYSES), arr.ind = TRUE)
   if(length(AUC_pos_max)>1){id=sample(1:length(AUC_pos_max),1);AUC_pos_max=AUC_pos_max[id]}
   couple_hp=meilleur_couple(c(0.20,0.40,0.60,0.80),c(2^(-5),2^(-3),2^(-1),2^(1),2^(3),2^(5)),ANALYSES[[AUC_pos_max]])
   resultats_rlp_rpc=rbind(resultats_rlp_rpc,couple_hp)
   
   resultats_rlp_r=rbind(resultats_rlp_r,RLP_proc_rec(seq(from = 0, to = 1, by = 0.10),h2o_train,h2o_valid,h2o_test)[length(seq(from = 0, to = 1, by = 0.10)),])
   
   
   # Optimisations pour MVS
   #Noyau gaussien 
   ANALYSE_1_svm_ng=anal_sens(c(2^(-5),2^(-3)),c(2^(-2),2^(0)),"svm_gauss",15,2,2,train,valid)
   ANALYSE_2_svm_ng=anal_sens(c(2^(-5),2^(-3)),c(2^(-2),2^(0)),"svm_gauss",15,2,3,train,valid)
   ANALYSE_3_svm_ng=anal_sens(c(2^(-5),2^(-3)),c(2^(-2),2^(0)),"svm_gauss",15,3,2,train,valid)
   ANALYSE_4_svm_ng=anal_sens(c(2^(-5),2^(-3)),c(2^(-2),2^(0)),"svm_gauss",15,3,3,train,valid)
   ANALYSES_svm_gauss=list(ANALYSE_1_svm_ng,ANALYSE_2_svm_ng,ANALYSE_3_svm_ng,ANALYSE_4_svm_ng)
   AUC_ANALYSES_svm_gauss=c(max(ANALYSE_1_svm_ng[[length(ANALYSE_1_svm_ng)]]),max(ANALYSE_2_svm_ng[[length(ANALYSE_2_svm_ng)]]),max(ANALYSE_3_svm_ng[[length(ANALYSE_3_svm_ng)]]),
                          max(ANALYSE_4_svm_ng[[length(ANALYSE_4_svm_ng)]]))
   AUC_pos_max=which(AUC_ANALYSES_svm_gauss == max(AUC_ANALYSES_svm_gauss), arr.ind = TRUE)
   if(length(AUC_pos_max)>1){id=sample(1:length(AUC_pos_max),1);AUC_pos_max=AUC_pos_max[id]}
   couple_hp=meilleur_couple(c(2^(-5),2^(-3)),c(2^(-2),2^(0)),ANALYSES_svm_gauss[[AUC_pos_max]])
   resultats_mvs_rpc_ng=rbind(resultats_mvs_rpc_ng,couple_hp)
   
   # Noyau linéaire
   ANALYSE_1_svm_nl=anal_sens(1,c(2^(-5),2^(-3),2^(-1),2^(1),2^(3),2^(5)),"svm_lin",15,NULL,2,train,valid)
   ANALYSE_2_svm_nl=anal_sens(1,c(2^(-5),2^(-3),2^(-1),2^(1),2^(3),2^(5)),"svm_lin",15,NULL,3,train,valid)
   ANALYSES_svm_lin=list(ANALYSE_1_svm_nl,ANALYSE_2_svm_nl)
   AUC_ANALYSES_svm_lin=c(max(ANALYSE_1_svm_nl[[length(ANALYSE_1_svm_nl)]]),max(ANALYSE_2_svm_nl[[length(ANALYSE_2_svm_nl)]]))
   AUC_pos_max=which(AUC_ANALYSES_svm_lin == max(AUC_ANALYSES_svm_lin), arr.ind = TRUE)
   if(length(AUC_pos_max)>1){id=sample(1:length(AUC_pos_max),1);AUC_pos_max=AUC_pos_max[id]}
   couple_hp=meilleur_couple(c(2^(-5),2^(-3),2^(-1),2^(1),2^(3),2^(5)),rep(0,6),ANALYSES_svm_lin[[AUC_pos_max]])
   resultats_mvs_rpc_nl=rbind(resultats_mvs_rpc_nl,couple_hp[-2])
   
   # Optimisations pour MGB #
   resultats_gbm_pd=rbind(resultats_gbm_pd,MGB_proc_aut(h2o_train,h2o_valid,h2o_test))
   resultats_gbm_rpg=rbind(resultats_gbm_rpg,MGB_proc_rpg_rs(h2o_train,h2o_valid,h2o_test,"grid",c(25,50,75,100,125),c(4,5,6),c(0.01,0.05,0.1,0.15,0.25)))
   resultats_gbm_ra=rbind(resultats_gbm_ra,MGB_proc_rpg_rs(h2o_train,h2o_valid,h2o_test,"random",seq(25,175,5),seq(1,10),seq(0.001,0.101,0.005)))
   h2o.removeAll()
   }
  #Extra steps
  colnames(resultats_rlp_pd)=c("alpha","lambda","AUC")
  colnames(resultats_rlp_rpc)=c("alpha","lambda","AUC")
  colnames(resultats_rlp_r)=c("alpha","lambda","AUC")
  
  colnames(resultats_mvs_rpc_ng)=c("gamma","cout","AUC")
  colnames(resultats_mvs_rpc_nl)=c("cout","AUC")
  
  colnames(resultats_gbm_pd)=c("learn_rate","max_depth","ntrees","AUC")
  colnames(resultats_gbm_rpg)=c("learn_rate","max_depth","ntrees","AUC")
  colnames(resultats_gbm_ra)=c("learn_rate","max_depth","ntrees","AUC")
  
# Export tables of results 
write.csv(resultats_rlp_pd, file = paste("C:/Users/Louis-Marc/Desktop/SELECT/data/resultats/RLP/Algo",j,"/resultats_rlp_pd.csv",sep = ""),row.names = F)
write.csv(resultats_rlp_rpc, file = paste("C:/Users/Louis-Marc/Desktop/SELECT/data/resultats/RLP/Algo",j,"/resultats_rlp_rpc.csv",sep = ""),row.names = F)
write.csv(resultats_rlp_r, file = paste("C:/Users/Louis-Marc/Desktop/SELECT/data/resultats/RLP/Algo",j,"/resultats_rlp_r.csv",sep = ""),row.names = F)
  
write.csv(resultats_mvs_rpc_nl, file = paste("C:/Users/Louis-Marc/Desktop/SELECT/data/resultats/MVS/Algo",j,"/resultats_mvs_rpc_nl.csv",sep=""),row.names = F)
write.csv(resultats_mvs_rpc_ng, file = paste("C:/Users/Louis-Marc/Desktop/SELECT/data/resultats/MVS/Algo",j,"/resultats_mvs_rpc_ng.csv",sep=""),row.names = F)
  
write.csv(resultats_gbm_pd, file = paste("C:/Users/Louis-Marc/Desktop/SELECT/data/resultats/MGB/Algo",j,"/resultats_gbm_rpc_pd.csv",sep=""),row.names = F)
write.csv(resultats_gbm_rpg, file = paste("C:/Users/Louis-Marc/Desktop/SELECT/data/resultats/MGB/Algo",j,"/resultats_gbm_rpc_rpg.csv",sep=""),row.names = F)
write.csv(resultats_gbm_ra, file = paste("C:/Users/Louis-Marc/Desktop/SELECT/data/resultats/MGB/Algo",j,"/resultats_gbm_rpc_ra.csv",sep=""),row.names = F)
}


######################################################################
########## Module: Analyses des performances  ########################
######################################################################

basic_path="C:/Users/Louis-Marc/Desktop/SELECT/data/resultats"


## Importation des données des méthodes pour un classificateur et un ##
##          algorithme de sélection de variable fixé.                ##

# RLP 
RLP_s1=import_perf(basic_path,"RLP","SELECT1")
rm(pd.csv);rm(r.csv);rm(rpc.csv)
aov0=aov(AUC~bloc+methode,data=RLP_s1)
anova(aov0)
png("C:/Users/Louis-Marc/Desktop/SELECT/data/residus/meilleures performances/RLP_s1.png", width=7, height=5, units="in", res=300)
residus_graphiques(RLP_s1)
dev.off()
TukeyHSD(aov0,"methode",ordered=TRUE, conf.level=0.95)
moyenne_RLP_s1 = c(mean(RLP_s1[RLP_s1$methode == "pd", ]$AUC),mean(RLP_s1[RLP_s1$methode == "r", ]$AUC),mean(RLP_s1[RLP_s1$methode == "rpc", ]$AUC))

RLP_s2=import_perf(basic_path,"RLP","SELECT2")
rm(pd.csv);rm(r.csv);rm(rpc.csv)
aov1=aov(AUC~bloc+methode,data=RLP_s2)
anova(aov1)
png("C:/Users/Louis-Marc/Desktop/SELECT/data/residus/meilleures performances/RLP_s2.png", width=7, height=5, units="in", res=300)
residus_graphiques(RLP_s2)
dev.off()
TukeyHSD(aov1,"methode",ordered=TRUE, conf.level=0.95)
moyenne_RLP_s2 = c(mean(RLP_s2[RLP_s2$methode == "pd", ]$AUC),mean(RLP_s2[RLP_s2$methode == "r", ]$AUC),mean(RLP_s2[RLP_s2$methode == "rpc", ]$AUC))

RLP_s3=import_perf(basic_path,"RLP","SELECT3")
rm(pd.csv);rm(r.csv);rm(rpc.csv)
aov2=aov(AUC~bloc+methode,data=RLP_s3)
anova(aov2)
png("C:/Users/Louis-Marc/Desktop/SELECT/data/residus/meilleures performances/RLP_s3.png", width=7, height=5, units="in", res=300)
residus_graphiques(RLP_s3)
dev.off()
TukeyHSD(aov2,"methode",ordered=TRUE, conf.level=0.95)
moyenne_RLP_s3 = c(mean(RLP_s3[RLP_s3$methode == "pd", ]$AUC),mean(RLP_s3[RLP_s3$methode == "r", ]$AUC),mean(RLP_s3[RLP_s3$methode == "rpc", ]$AUC))

# MSV
MVS_s1=import_perf(basic_path,"MVS","SELECT1")
rm(ng.csv);rm(nl.csv)
aov3=aov(AUC~bloc+methode,data=MVS_s1)
anova(aov3)
png("C:/Users/Louis-Marc/Desktop/SELECT/data/residus/meilleures performances/MVS_s1.png", width=7, height=5, units="in", res=300)
residus_graphiques(MVS_s1)
dev.off()
TukeyHSD(aov3,"methode",ordered=TRUE, conf.level=0.95)
moyenne_MVS_s1 = c(mean(MVS_s1[MVS_s1$methode == "nl", ]$AUC),mean(MVS_s1[MVS_s1$methode == "ng", ]$AUC))

MVS_s2=import_perf(basic_path,"MVS","SELECT2")
rm(ng.csv);rm(nl.csv)
aov4=aov(AUC~bloc+methode,data=MVS_s2)
anova(aov4)
png("C:/Users/Louis-Marc/Desktop/SELECT/data/residus/meilleures performances/MVS_s2.png", width=7, height=5, units="in", res=300)
residus_graphiques(MVS_s2)
dev.off()
TukeyHSD(aov4,"methode",ordered=TRUE, conf.level=0.95)
moyenne_MVS_s2 = c(mean(MVS_s2[MVS_s2$methode == "nl", ]$AUC),mean(MVS_s2[MVS_s2$methode == "ng", ]$AUC))

MVS_s3=import_perf(basic_path,"MVS","SELECT3")
rm(ng.csv);rm(nl.csv)
aov5=aov(AUC~bloc+methode,data=MVS_s3)
anova(aov5)
png("C:/Users/Louis-Marc/Desktop/SELECT/data/residus/meilleures performances/MVS_s3.png", width=7, height=5, units="in", res=300)
residus_graphiques(MVS_s3)
dev.off()
TukeyHSD(aov5,"methode",ordered=TRUE, conf.level=0.95)
moyenne_MVS_s3 = c(mean(MVS_s3[MVS_s3$methode == "nl", ]$AUC),mean(MVS_s3[MVS_s3$methode == "ng", ]$AUC))

# MGB
MGB_s1=import_perf(basic_path,"MGB","SELECT1")
rm(pd.csv);rm(ra.csv);rm(rpg.csv)
aov6=aov(AUC~bloc+methode,data=MGB_s1)
anova(aov6)
png("C:/Users/Louis-Marc/Desktop/SELECT/data/residus/meilleures performances/MGB_s1.png", width=7, height=5, units="in", res=300)
residus_graphiques(MGB_s1)
dev.off()
TukeyHSD(aov6,"methode",ordered=TRUE, conf.level=0.95)
moyenne_MGB_s1 = c(mean(MGB_s1[MGB_s1$methode == "pd", ]$AUC),mean(MGB_s1[MGB_s1$methode == "ra", ]$AUC),mean(MGB_s1[MGB_s1$methode == "rpg", ]$AUC))

MGB_s2=import_perf(basic_path,"MGB","SELECT2")
rm(pd.csv);rm(ra.csv);rm(rpg.csv)
aov7=aov(AUC~bloc+methode,data=MGB_s2)
anova(aov7)
png("C:/Users/Louis-Marc/Desktop/SELECT/data/residus/meilleures performances/MGB_s2.png", width=7, height=5, units="in", res=300)
residus_graphiques(MGB_s2)
dev.off()
TukeyHSD(aov7,"methode",ordered=TRUE, conf.level=0.95)
moyenne_MGB_s2 = c(mean(MGB_s2[MGB_s2$methode == "pd", ]$AUC),mean(MGB_s2[MGB_s2$methode == "ra", ]$AUC),mean(MGB_s2[MGB_s2$methode == "rpg", ]$AUC))

MGB_s3=import_perf(basic_path,"MGB","SELECT3")
rm(pd.csv);rm(ra.csv);rm(rpg.csv)
aov8=aov(AUC~bloc+methode,data=MGB_s3)
anova(aov8)
png("C:/Users/Louis-Marc/Desktop/SELECT/data/residus/meilleures performances/MGB_s3.png", width=7, height=5, units="in", res=300)
residus_graphiques(MGB_s3)
dev.off()
TukeyHSD(aov8,"methode",ordered=TRUE, conf.level=0.95)


#####################################################################
## Évaluation des évolutions des algorithmes (basée ensemble test) ##
#####################################################################

# RLP: pd
RLP_pd_ANOVA = ANOVA_evol_algo("C:/Users/Louis-Marc/Desktop/SELECT/data","RLP","pd",1)
aov0=aov(AUC~bloc+algo,data=RLP_pd_ANOVA)
aov_0=aov(precision~bloc+algo,data=RLP_pd_ANOVA)
anova(aov0) # 0.8677 / 0.8670

# RLP: r
RLP_r_ANOVA = ANOVA_evol_algo("C:/Users/Louis-Marc/Desktop/SELECT/data","RLP","r",1)
aov1=aov(AUC~bloc+algo,data=RLP_r_ANOVA)
aov_1=aov(precision~bloc+algo,data=RLP_r_ANOVA)
anova(aov1) # 0.64112 / 0.4552 

# RLP: rpc
RLP_rpc_ANOVA = ANOVA_evol_algo("C:/Users/Louis-Marc/Desktop/SELECT/data","RLP","rpc",1)
aov2=aov(AUC~bloc+algo,data=RLP_rpc_ANOVA)
aov_2=aov(precision~bloc+algo,data=RLP_rpc_ANOVA)
anova(aov2) # 0.9688 / 0.8290

# MVS: ng
MVS_ng_ANOVA = ANOVA_evol_algo("C:/Users/Louis-Marc/Desktop/SELECT/data","MVS","ng",1)
aov3=aov(AUC~bloc+algo,data=MVS_ng_ANOVA)
aov_3=aov(precision~bloc+algo,data=MVS_ng_ANOVA)
anova(aov3) # 0.1897 / 0.2945

# MVS: nl
MVS_nl_ANOVA = ANOVA_evol_algo("C:/Users/Louis-Marc/Desktop/SELECT/data","MVS","nl",1)
aov4=aov(AUC~bloc+algo,data=MVS_nl_ANOVA)
aov_4=aov(precision~bloc+algo,data=MVS_nl_ANOVA)
anova(aov4) #0.8470 / 0.7501

# MGB: pd
MGB_pd_ANOVA=ANOVA_evol_algo("C:/Users/Louis-Marc/Desktop/SELECT/data","MGB","pd",1)
aov5=aov(AUC~bloc+algo,data=MGB_pd_ANOVA)
aov_5=aov(precision~bloc+algo,data=MGB_pd_ANOVA)
anova(aov5) # 0.2111 / 0.03252

# MGB: ra
MGB_ra_ANOVA=ANOVA_evol_algo("C:/Users/Louis-Marc/Desktop/SELECT/data","MGB","ra",1)
aov6=aov(AUC~bloc+algo,data=MGB_ra_ANOVA)
aov_6=aov(precision~bloc+algo,data=MGB_ra_ANOVA)
anova(aov6) # 0.44457 / .80358 

# MGB: rpg
MGB_rpg_ANOVA=ANOVA_evol_algo("C:/Users/Louis-Marc/Desktop/SELECT/data","MGB","rpg",1)
aov7=aov(AUC~bloc+algo,data=MGB_rpg_ANOVA)
aov_7=aov(precision~bloc+algo,data=MGB_rpg_ANOVA)
anova(aov7) # 0.1550 / 0.88609


