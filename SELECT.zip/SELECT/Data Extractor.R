# Nom: Module de partitionnement et de selection de variables.
# Auteur: Louis-Marc Mercier
# Date: 22 juillet 2017

# Module pour separer les donnees et faire la selection de variables selon les
# differents algorithmes.

# Importation des donnees brutes (necessite l'installation manuelle du package datamicroarray).
library(datamicroarray)
data('gravier', package = 'datamicroarray')
y=as.integer(gravier$y)-1
data=cbind(gravier$x,y)

####################################################
############ Separation des donnees ################
####################################################

# Stratification des partitions selon la presence de la maladie
basic_path = "C:/Users/Louis-Marc/Desktop/SELECT/data"
data_healthy=subset(data,data$y==0)
data_sick=subset(data,data$y==1)
yh=data_healthy$y
ys=data_sick$y

# Paritionnement des donnees pour les 10 experiences.
for(i in 1:10){
  set.seed(i)
  print(i)
  
  # Train
  splitIndexHT=sample(c(1:length(yh)),floor(0.70*length(yh)))
  splitIndexST=sample(c(1:length(ys)),floor(0.70*length(ys)))
  train=rbind(data_healthy[splitIndexHT,],data_sick[splitIndexST,])
  
  # Valid
  splitIndexHV1=c(1:length(yh))[-splitIndexHT]
  splitIndexSV1=c(1:length(ys))[-splitIndexST]
  splitIndexHV=sample(splitIndexHV1,floor(0.15*length(yh)))
  splitIndexSV=sample(splitIndexSV1,floor(0.15*length(ys)))
  valid=rbind(data_healthy[splitIndexHV,],data_sick[splitIndexSV,])
  
  # Test
  splitIndexH=c(1:length(yh))[-c(splitIndexHT,splitIndexHV)]
  splitIndexS=c(1:length(ys))[-c(splitIndexST,splitIndexSV)]
  E1=data_healthy[splitIndexH,]
  E2=data_sick[splitIndexS,]
  test=rbind(E1,E2)
  
  # Melanger les ensembles de données
  train = train[sample(nrow(train)),]
  valid = valid[sample(nrow(valid)),]
  test = test[sample(nrow(test)),]
  
  # Exporter les ensembles de données
  Export(basic_path,"train",train,i)
  Export(basic_path,"valid",valid,i)
  Export(basic_path,"test",test,i)
}

####################################################
############ Sélection de variables ################
####################################################

for(i in 1:10){
  noms=Import(paste(basic_path,"/exp",i,sep=""),"*.csv")
  test=get(noms[1])
  train=get(noms[2])
  valid=get(noms[3])
  rm(list=noms)
  
  # Selection de variables avec SELECT() et exportation.
 # selection_1=SELECT(train,valid,test,0.90,0.19,0.60,0.0977)
 # train_PCA=selection_1[[1]]
  #valid_PCA=selection_1[[2]]
 # test_PCA=selection_1[[3]]
 # Export(basic_path,"/Transformed_1/train_PCA_1_",train_PCA,i)
 # Export(basic_path,"/Transformed_1/valid_PCA_1_",valid_PCA,i)
 # Export(basic_path,"/Transformed_1/test_PCA_1_",test_PCA,i)
 # rm(list=c("train_PCA","valid_PCA","test_PCA"))
  
  # Selection de variables avec SELECT() et exportation.
  selection_2=SELECT2(train,valid,test,0.90,0,15,15,0.05,0.025,0.19,0.60,0.0977)
  train_PCA=selection_2[[1]]
  valid_PCA=selection_2[[2]]
  test_PCA=selection_2[[3]]
  Export(basic_path,"/Transformed_2/train_PCA_2_",train_PCA,i)
  Export(basic_path,"/Transformed_2/valid_PCA_2_",valid_PCA,i)
  Export(basic_path,"/Transformed_2/test_PCA_2_",test_PCA,i)
  rm(list=c("train_PCA","valid_PCA","test_PCA"))
  
  # Selection de variables avec SELECT 3().
  #selection_3=SELECT3(train,valid,test,0.90,1,0.60,0.0977)
  #train_PCA=selection_3[[1]]
  #valid_PCA=selection_3[[2]]
  #test_PCA=selection_3[[3]]
  #Export(basic_path,"/Transformed_3/train_PCA_3_",train_PCA,i)
  #Export(basic_path,"/Transformed_3/valid_PCA_3_",valid_PCA,i)
  #Export(basic_path,"/Transformed_3/test_PCA_3_",test_PCA,i)
  #rm(list=c("train_PCA","valid_PCA","test_PCA"))
}


